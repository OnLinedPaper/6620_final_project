<?php

$dbhost = "mysql1.cs.clemson.edu";
$dbuser = "metube_8ma5";
$dbpass = "metube6620";
$database = "metube_w1bj";
?>
